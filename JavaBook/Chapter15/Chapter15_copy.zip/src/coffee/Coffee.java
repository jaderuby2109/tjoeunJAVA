package coffee;

public abstract class Coffee {
    public abstract void brewing();
}
