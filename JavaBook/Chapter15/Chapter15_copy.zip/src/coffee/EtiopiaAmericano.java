package coffee;

public class EtiopiaAmericano extends Coffee{

	@Override
	public void brewing() {

		System.out.print("EtiopiaAmericano ");
	}

}
